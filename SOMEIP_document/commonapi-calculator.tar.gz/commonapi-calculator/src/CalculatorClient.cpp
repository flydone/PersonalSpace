#include <iostream>
#include <string>
#include <unistd.h>
#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/CalculatorProxy.hpp>
#include <chrono>
  
using namespace v1::commonapi;
  
int main() {
    int32_t result = 0;
    CommonAPI::CallStatus callStatus;
    std::shared_ptr <CommonAPI::Runtime > runtime = CommonAPI::Runtime::get();
    std::shared_ptr<CalculatorProxy<>> myProxy = runtime->buildProxy<CalculatorProxy>("local", "commonapi.Calculator","calculator_client");
  
    if(nullptr == myProxy) {

       std::cout << "Unable to build proxy object for CalculatorService!!!" << std::endl;

    } else {

       std::cout << "Checking availability of CalculatorService!!!" << std::endl;

       while (!myProxy->isAvailable()) {
           std::this_thread::sleep_for(std::chrono::milliseconds(500));
       }

       std::cout << "Available..." << std::endl;

       while(1) {
		
	myProxy->add(20,10, callStatus, result);
	std::cout << "Received results for add(20,10) => " << result << std::endl;
		
	myProxy->subtract(20,10, callStatus, result);
	std::cout << "Received results for subtract(20,10) => " << result << std::endl;

	myProxy->multiply(20,10, callStatus, result);
	std::cout << "Received results for multiply(20,10) => " << result << std::endl;

        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
      }
    }
     
    return 0;
} 
