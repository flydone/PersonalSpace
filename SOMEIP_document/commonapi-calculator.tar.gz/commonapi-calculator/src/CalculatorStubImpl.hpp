#ifndef CALCULATORSTUBIMPL_H_
#define CALCULATORSTUBIMPL_H_
  
#include <CommonAPI/CommonAPI.hpp>
#include <v1/commonapi/CalculatorStubDefault.hpp>
  
namespace commonapi
{
namespace calculator
{
class CalculatorStubImpl: public v1::commonapi::CalculatorStubDefault {
public:
    CalculatorStubImpl();
    virtual ~CalculatorStubImpl();
    virtual void add(const std::shared_ptr<CommonAPI::ClientId> _client, int32_t _a, int32_t _b, addReply_t _return);
    virtual void subtract(const std::shared_ptr<CommonAPI::ClientId> _client, int32_t _a, int32_t _b, addReply_t _return);
    virtual void multiply(const std::shared_ptr<CommonAPI::ClientId> _client, int32_t _a, int32_t _b, addReply_t _return);
};
} // namespace calculator
} // namespace commonapi
#endif /* CALCULATORSTUBIMPL_H_ */
