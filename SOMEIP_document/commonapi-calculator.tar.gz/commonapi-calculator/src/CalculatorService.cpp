#include <iostream>
#include <thread>
#include <CommonAPI/CommonAPI.hpp>
#include "CalculatorStubImpl.hpp"
  
using namespace std;
using namespace commonapi::calculator;
 
int main() {
    std::shared_ptr<CommonAPI::Runtime> runtime = CommonAPI::Runtime::get();
    std::shared_ptr<CalculatorStubImpl> calculatorService = std::make_shared<CalculatorStubImpl>();
    if(!runtime->registerService("local", "commonapi.Calculator", calculatorService, "calculator_service")) {

      std::cout << "Failed to register CalculatorService!!!" << std::endl;

    } else {

      std::cout << "Successfully registered CalculatorService!!!" << std::endl;
    
      while (true) {
        std::cout << "Waiting for calls... (Abort with CTRL+C)" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(30));
      }
    }
   
    return 0;
 } 
