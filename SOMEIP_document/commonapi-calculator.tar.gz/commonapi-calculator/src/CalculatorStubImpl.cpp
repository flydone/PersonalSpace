#include "CalculatorStubImpl.hpp"
 
namespace commonapi
{
namespace calculator
{

CalculatorStubImpl::CalculatorStubImpl() 
{ 
}

CalculatorStubImpl::~CalculatorStubImpl() 
{ 
}

void CalculatorStubImpl::add(const std::shared_ptr<CommonAPI::ClientId> _client, int32_t _a, int32_t _b, addReply_t _return) {
	int32_t result = 0;
	
	std::cout << "Received add(" << std::to_string(_a) << "," << std::to_string(_b) << ")" << std::endl;
	
	result = _a + _b;
	
	_return(result);
	
}

void CalculatorStubImpl::subtract(const std::shared_ptr<CommonAPI::ClientId> _client, int32_t _a, int32_t _b, subtractReply_t _return) {
	int32_t result = 0;
	
	std::cout << "Received subtract(" << std::to_string(_a) << "," << std::to_string(_b) << ")" << std::endl;	
	
	if(_a > _b) {
		result = _a - _b;
	} else {
		result = _b - _a;
	}

	_return(result);
}

void CalculatorStubImpl::multiply(const std::shared_ptr<CommonAPI::ClientId> _client, int32_t _a, int32_t _b, multiplyReply_t _return) {
	int32_t result = 0;
	
	std::cout << "Received multiply(" << std::to_string(_a) << "," << std::to_string(_b) << ")" << std::endl;	
	
	result = _a * _b;
	
	_return(result);
}
} // namespace calculator
} // namespace commonapi
