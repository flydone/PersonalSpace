
#include "DVRFileOperationImpl.hpp"
#include <iostream>
#include <thread>

using namespace v1::GREATWALL::DVR_VIMS;
DVRFileOperationImpl::DVRFileOperationImpl(){

}
DVRFileOperationImpl::~DVRFileOperationImpl(){

}

void DVRFileOperationImpl::SDCardFormat(const std::shared_ptr<CommonAPI::ClientId> _client, DVRFileOperation::SDCardOption _SDCardOption, SDCardFormatReply_t _reply) {
    //TBD: add business code
    DVRFileOperationStubDefault::SDCardFormat(_client, _SDCardOption, _reply);
}

