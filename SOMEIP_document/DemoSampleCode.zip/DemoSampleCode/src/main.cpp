#include <iostream>
#include <thread>
#include <sstream>
#include <CommonAPI/CommonAPI.hpp>
#include "DVRFileOperationImpl.hpp"

using namespace v1::GREATWALL::DVR_VIMS;
using DVRFileOperationService = std::shared_ptr<DVRFileOperationImpl>;

int main(int argc, char* argv[]){
    std::cout << "DVR File Operation service startup" << std::endl;
    setenv("VSOMEIP_CONFIGURATION", "/vendor/etc/someip/dvrvims.json", 1);
    setenv("VSOMEIP_APPLICATION_NAME", "dvrvimsserver", 1);
	std::shared_ptr<CommonAPI::Runtime> runtime = CommonAPI::Runtime::get();
	DVRFileOperationService tService = std::make_shared<DVRFileOperationImpl>();
	bool rOk = runtime->registerService("local", "DVRFileOperation01", tService);
	if (rOk){
			std::cout << "Register DVRFileOperation01 ok" << std::endl;
	}else{
			std::cout << "Register DVRFileOperation01 fail" << std::endl;
	}
	while(true){
	   std::cout << "Waitting for calls... (Abort with CTRL+C)" << std::endl;
	   std::this_thread::sleep_for(std::chrono::seconds(1));
	}
	/*bool unregisterService(const std::string &_domain, const std::string &_interface, const std::string &_instance);*/
	bool bunregister = runtime->unregisterService("local", DVRFileOperationImpl::StubInterface::getInterface(), "DVRFileOperation01");
	return 0;
}
