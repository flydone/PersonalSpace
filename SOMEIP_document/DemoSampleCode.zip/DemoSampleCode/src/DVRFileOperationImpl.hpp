
#include <CommonAPI/CommonAPI.hpp>
#include <v1/GREATWALL/DVR_VIMS/DVRFileOperationStubDefault.hpp>
#include <string>

using namespace v1::GREATWALL::DVR_VIMS;
class DVRFileOperationImpl : public DVRFileOperationStubDefault, 
    public std::enable_shared_from_this<DVRFileOperationImpl>
{
public:
    DVRFileOperationImpl();
    virtual ~DVRFileOperationImpl();
	
	virtual void SDCardFormat(const std::shared_ptr<CommonAPI::ClientId> _client, DVRFileOperation::SDCardOption _SDCardOption, SDCardFormatReply_t _reply);
};
